import pandas as pd
from openai import OpenAI
from pathlib import Path
import os
from dotenv import load_dotenv
from utils import load_gpt_files, save_gpt_response_txt
load_dotenv()

OPENAI_API_KEY =  os.getenv("OPENAI_API_KEY")
OpenAI.api_key = OPENAI_API_KEY
_TODAY = pd.Timestamp.today().strftime("%Y_%m_%d_%H_%M")
gpt_4 = "gpt-4-vision-preview"
_ROOT = Path(__file__).parent

client = OpenAI(
    api_key=OPENAI_API_KEY,
)

image_descipcion_prompt = load_gpt_files(_ROOT, "txt")
IMAGES = load_gpt_files(_ROOT, "json")

responses_to_df = []

for image in IMAGES["Images"].values():
  response = client.chat.completions.create(
    model= gpt_4,
    messages=[
      {
        "role": "user",
        "content": [
          {"type": "text", "text": image_descipcion_prompt},
          {
            "type": "image_url",
            "image_url": {
              "url": image, # IMAGES["Images"]["image3"]
              "detail": "low" # "low" or "high" // TODO: Comprobar gasto de tokens  y si es necesario
            },

          },
        ],
      },
        {
        "role": "system",
        "content": IMAGES["Machine_prompt"],
    },
    ],
    max_tokens=1000,
  )


  # list and remove all files in directory with pathlib
  for file in _ROOT.glob("image_responses/*.txt"):
      file.unlink()

  # responses_to_df = []
  for choice in response.choices:
    # save_gpt_response_txt(_ROOT, choice.message.content)
    data = { "timestamp": _TODAY,
            "image_response": choice.message.content}
    responses_to_df.append(data)
    print(choice.message.content[:50])

df = pd.DataFrame(responses_to_df)
df.to_csv(f"{_ROOT}/image_responses/image_responses_{_TODAY}.csv", index=False)
